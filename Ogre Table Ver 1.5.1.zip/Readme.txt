Thank you for downloading my table.
You have been chosen by the Almighty Ogrelord to aid him in his great cause.

You have been granted a table you can use with Cheat Engine 6.6 (included in the .zip) that will transform you into an Ogre.
When transformed you are allowed to perform special Ogre Magic and have access to powerful tools.
These spells will remain active untill you close your game.
To know what everything does, right click the script and go to "Open script".

When the spells are enabled they are replaced by existing spells (shown by the script description).
This means you will not be able to use the original spells when activated.

If you like this table, please share it with your friends!

The safest way to use this table:
1) Start a new character
2) Give it an Ogre related name (over-Ogre puns, X Ogre and Swamp Defender to name a few examples)
3) Turn yourself into an Ogre in the character creator by opening and activating the table
4) Figure out how everything in the table works, maybe spawn in some items
5) Go to the area you want to defend (Halfway Fortess or Pontiff are the best places)
6) Have fun!

My general tip are to pick a spot, activate the dried fingers, then unlock the invader limit and have some fun.

--USE THIS TABLE AT YOUR OWN RISK, YOU MAY OR MAY NOT GET BANNED--
--IF YOU GET BANNED, DELETE YOUR CHARACTERS AND WAIT 2-5 WEEKS FOR AN UNBAN--


Your Ogrelord

-GonthorianDX (Its all Ogre now)



